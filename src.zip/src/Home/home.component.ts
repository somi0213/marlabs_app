import {Component} from '@angular/core';

@Component({
    selector:'movie',
    templateUrl : './home.component.html'

})
export class HomeComponent{
    title:string="Xmen";
}

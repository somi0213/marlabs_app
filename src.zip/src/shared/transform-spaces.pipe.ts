import {Pipe,PipeTransform} from '@angular/core';

@Pipe({
  name: 'PipeToPower'

})
    


export class PowerPipe implements PipeTransform{
    transform(value: number, power:number ) : number{

        return value*power;
    }
}
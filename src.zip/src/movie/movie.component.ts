import {Component} from '@angular/core';

@Component({
    selector:'movie',
    template : `<h1>welcome to movie</h1>`

})
export class MovieComponent{
    title:string="Xmen";
}

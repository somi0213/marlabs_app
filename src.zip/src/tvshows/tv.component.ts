import {Component, OnInit, OnChanges, OnDestroy} from '@angular/core';
import {IShow} from './tv';
@Component({
    selector: 'tv',
    templateUrl :'./tv.component.html',
    styleUrls:['./tv.component.css']
})
export class TvComponent implements OnInit, OnChanges, OnDestroy{
    constructor(){
        console.log("At constructor");
        this.showName = "najar";
        console.log(this.showName); //constructor loads first, if we are putting ngoninit before constructoer then also constructor loads first.
        //here, no need of constructor for understanding purpose only we are declarign constructor.
    } 
    ngOnInit():void{
        this.showName = 'sargun';
        console.log("At the init phase!" + this.showName);
    }
     ngOnChanges():void{
        this.showName = 'sargun';
        console.log("At the change detection phase!");
    }
     ngOnDestroy():void{
        console.log("destroying component");
    }
    showName:string= 'NAJAR';
    broadcaster : string ='15 july';
    time: number = 8;
    imgWidth:number=400;
    imgHeight:number=600;

    show: IShow[] = [{

        showId : 1,//here, we can take string also but this can create anbiguity so for this we will create interface. IShOw
        showName: "najar",
        showStar : "mohena",
        showGenre : "drama",
        showRating : 5,
        showImg :""
    },
    {

         showId : 2,
        showName : "najar",
        showStar: "mohena",
        showGenre : "drama",
        showRating: 5,
        showImg :"",
    },
    {
         showId : 3,
        showName : "najar",
        showStar : "mohena",
        showGenre: "drama",
        showRating : 5,
        showImg :"",
    },
    {
         showId : 4,
        showName : "najar",
        showStar: "mohena",
        showGenre : "drama",
        showRating : 5,
        showImg :"",
    }]

/*show = [
    {showName : 'najar', actor:'mohena'} ,
    {showName : 'sargun', actor:'karan'} ,
    {showName : 'avengers', actor:'scarl'} ,
     {showName : 'najar', actor:'mohena'} ,
    {showName : 'sargun', actor:'karan'} ,
    {showName : 'avengers', actor:'scarl'} ,
     {showName : 'najar', actor:'mohena'} ,
    {showName : 'sargun', actor:'karan'} ,
    {showName : 'avengers', actor:'scarl'} ,
     {showName : 'najar', actor:'mohena'} ,
    {showName : 'sargun', actor:'karan'} ,
    {showName : 'avengers', actor:'scarl'} ,

    ];

shows() : void{
    this.showName="NAJAR";
}*/
}
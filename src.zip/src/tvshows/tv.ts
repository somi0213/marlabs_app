
export interface IShow{
         "showId" : number;
        "showName" : string;
        "showStar" : string;
        "showGenre" : string;
        "showRating" : number;
        "showImg" : string;
}


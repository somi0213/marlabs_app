import {IShow} from './../tvshows/tv';
import {ActivatedRoute, Router} from '@angular/router';
import {OnInit, Component} from '@angular/core';

@Component({
    templateUrl:'./show-detail.component.html',


})

export class ShowDetailComponent implements OnInit{
    pgtitle: string = "show details";
show : IShow;
    constructor(private route:ActivatedRoute, private router:Router){};

    ngOnInit(){
        let id = +this.route.snapshot.paramMap.get('id');
        this.pgtitle += ': ${id}';
        this.show = {
            'showId': id,
            'showName' : 'najar',
            'showGenre' : 'drama',
            'showRating' : 5,
            'showImg': 'some',
            'showStar' : 'mohena'
        };
    }
    onBack()
    {
        this.router.navigate(['/show']);
    }

}
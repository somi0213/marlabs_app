import{Component} from '@angular/core';

@Component({
    selector:'abt-us',
    template:'<h1>welcome movies</h1>'
//templateUrl:'./About.component.html',
//styleUrl:['./About.component.css']
})

export class AboutComponent{
    Title:string="its all about movies";
    contact:number=7987505802;
}
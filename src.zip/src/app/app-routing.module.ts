import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HomeComponent} from './../Home/home.component';
import {TvComponent} from './../tvshows/tv.component';
import {MovieComponent} from './../movie/movie.component';
//import {ShowDetailComponent} from 'src/ShowDetails/show-detail.component';



const routes: Routes = [
 { path:'home', component:HomeComponent},
 { path:'tv', component:TvComponent},
 {path:'movie', component:MovieComponent}
 //{path:'shows', component:ShowComponent},
 //{path:'showdetail', component:ShowDetailComponent},
//{path:'', component:HomeComponent, pathMatch:'full'},
//{path:'**', component:HomeComponent, pathMatch:'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

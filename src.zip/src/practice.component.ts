import {Component} from '@angular/core'

    @Component({
        selector:'prac',
        templateUrl:'./practice.component.html',
        styleUrls: ['./practice.component.css']
    })
    export class PracticeComponent{
        Title:string="this is for practice purpose only";
    }
    
